package osgp2.platform;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestHandleBatchHelper {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
