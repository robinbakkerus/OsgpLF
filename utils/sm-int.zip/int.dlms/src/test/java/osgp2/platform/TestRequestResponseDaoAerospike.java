package osgp2.platform;

import java.util.UUID;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.osgp.smint.SmIntAerospikeServer;
import org.osgp.smint.dbs.RequestResponseDao;
import org.osgp.smint.dbs.RequestResponseDaoImplAerospike;

import com.alliander.osgp.dlms.DlmsActionMsg;
import com.alliander.osgp.dlms.DlmsActionMsg.RequestType;
import com.alliander.osgp.dlms.DlmsActionRespMsg;
import com.alliander.osgp.dlms.DlmsReqRespMsg;
import com.alliander.osgp.dlms.DlmsRespCorrelIdMsg;
import com.alliander.osgp.shared.CommonMsg;
import com.google.protobuf.Descriptors;

public class TestRequestResponseDaoAerospike {

	private static SmIntAerospikeServer sAerospikeServer;

	@BeforeClass
	public static void beforeOnce() {
		sAerospikeServer = SmIntAerospikeServer.initialize("localhost", 3000);
	}

	@Test
	public void test() {
		RequestResponseDao dao = new RequestResponseDaoImplAerospike();
		final String correlid = UUID.randomUUID().toString();
		dao.saveRequest(makeRequestMsg(correlid));
		dao.updateWithResponse(correlid, "status", "response");
		String response = dao.getResponse(makeGetResponseCorrelIdMsg(correlid));
		System.out.println(response);
	}

	@AfterClass
	public static void cleanup() {
		sAerospikeServer.cleanup();
	}

	private DlmsReqRespMsg makeRequestMsg(final String correlid) {
		Descriptors.Descriptor descriptor = DlmsReqRespMsg.getDescriptor();

		DlmsActionMsg msgitem1 = DlmsActionMsg.newBuilder().setRequestType(RequestType.FINDEVENTS).build();
		DlmsActionMsg msgitem2 = DlmsActionMsg.newBuilder().setRequestType(RequestType.GET_CONFIGURATION).build();
		DlmsActionMsg msgitem3 = DlmsActionMsg.newBuilder().setRequestType(RequestType.GET_SPECIFIC_OBJECT).build();

		CommonMsg common = makeCommon(correlid);

		DlmsReqRespMsg request = DlmsReqRespMsg.newBuilder().setCommon(common)
				.addRepeatedField(descriptor.findFieldByName("actions"), msgitem1)
				.addRepeatedField(descriptor.findFieldByName("actions"), msgitem2)
				.addRepeatedField(descriptor.findFieldByName("actions"), msgitem3).build();
		return request;
	}

	private DlmsReqRespMsg makeRequestResponseMsg(final String correlid) {
		Descriptors.Descriptor descriptor = DlmsReqRespMsg.getDescriptor();

		DlmsActionMsg msgitem1 = DlmsActionMsg.newBuilder()
				.setRequestType(RequestType.FINDEVENTS)
				.setResponse(reqResp("ANTWOORD-1"))
				.build();
		DlmsActionMsg msgitem2 = DlmsActionMsg.newBuilder()
				.setRequestType(RequestType.GET_CONFIGURATION)
				.setResponse(reqResp("ANTWOORD-2"))
				.build();
		DlmsActionMsg msgitem3 = DlmsActionMsg.newBuilder()
				.setRequestType(RequestType.GET_SPECIFIC_OBJECT)
				.setResponse(reqResp("ANTWOORD-3"))
				.build();

		CommonMsg common = makeCommon(correlid);

		DlmsReqRespMsg response = DlmsReqRespMsg.newBuilder()
				.setCommon(common)
				.addRepeatedField(descriptor.findFieldByName("actions"), msgitem1)
				.addRepeatedField(descriptor.findFieldByName("actions"), msgitem2)
				.addRepeatedField(descriptor.findFieldByName("actions"), msgitem3).build();
		return response;
	}

	private CommonMsg makeCommon(final String correlid) {
		CommonMsg common = CommonMsg.newBuilder().setApplicationName("Appname").setDeviceId("EX12345")
				.setUserName("robinb").setCorrelId(correlid).build();
		return common;
	}

	private DlmsActionRespMsg reqResp(String value) {
		return DlmsActionRespMsg.newBuilder()
			.setResponse(value)
			.build();
	}
	
	private DlmsRespCorrelIdMsg makeGetResponseCorrelIdMsg(final String correlid) {
		return DlmsRespCorrelIdMsg.newBuilder().setCorrelid(correlid).build();
	}
			

}
