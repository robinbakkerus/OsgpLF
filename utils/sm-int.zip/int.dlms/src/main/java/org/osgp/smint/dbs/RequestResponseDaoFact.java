package org.osgp.smint.dbs;

public class RequestResponseDaoFact {

	private static RequestResponseDao dao = null;
	
	public static RequestResponseDao getDao() {
		if (dao==null) {
			dao = new RequestResponseDaoImplAerospike();
		}
		return dao;
	}
}
