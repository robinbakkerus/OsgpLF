package org.osgp.smint;

import com.alliander.osgp.dlms.DlmsReqRespMsg;
import com.alliander.osgp.dlms.DlmsRespCorrelIdMsg;
import com.alliander.osgp.dlms.SmIntHandleBatchesMsg;
import com.alliander.osgp.dlms.SmIntegrationServiceGrpc;
import com.alliander.osgp.shared.Osgp2Constants;

import io.grpc.stub.StreamObserver;

/**
Deze class vangt de berichten die door test-client worden verstuurd. 
In sendRequest wordt:
- eerste een correlId bepaald,
- dan wordt in de RequestResponseMgs, het correlId gezet
- dan wordt het bericht met dit correlid naar de request-actor in Core gestuurd, zie CoreRequestActor
- dan wordt het correlid als result terug gestuurd naar de test-client.
- en teslotte wordt de RequestResponseMgs in de dbs opgeslagen (Zie dao().saveRequest)

In getResponse, wordt met de gegeven correlId, het resultaat uit de database opgehaald en terug naar de client gestuurd.
*/
public class SmIntReqMgsHandler extends SmIntegrationServiceGrpc.AbstractSmIntegrationService implements Osgp2Constants {

	public SmIntReqMgsHandler() {
		super();
	}

	@Override
	public void dlmsRequest(DlmsReqRespMsg request, StreamObserver<DlmsRespCorrelIdMsg> responseObserver) {
		// TODO Auto-generated method stub
		super.dlmsRequest(request, responseObserver);
	}

	@Override
	public void handleBatches(SmIntHandleBatchesMsg request, StreamObserver<SmIntHandleBatchesMsg> responseObserver) {
		// TODO Auto-generated method stub
		super.handleBatches(request, responseObserver);
	}


}
