package org.osgp.smint.dbs;

import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.osgp.smint.SmIntAerospikeServer;

import com.aerospike.client.AerospikeClient;
import com.aerospike.client.Bin;
import com.aerospike.client.Key;
import com.aerospike.client.Record;
import com.aerospike.client.policy.RecordExistsAction;
import com.aerospike.client.policy.WritePolicy;
import com.alliander.osgp.dlms.DlmsReqRespMsg;
import com.alliander.osgp.dlms.DlmsRespCorrelIdMsg;
import com.alliander.osgp.shared.Osgp2Constants;

public class RequestResponseDaoImplAerospike implements RequestResponseDao {

	private static final Logger logger = Logger.getLogger(RequestResponseDaoImplAerospike.class.getName());

	private static final String NAMESPACE = Osgp2Constants.DBS_NAMESPACE_PLATFORM;
	private static final String TABLE_REQRESP_MSG = "request_response_data";
	private static final String CORRELID = "correlid";
	private static final String CREATED_AT = "created_at";
	private static final String MODIFIED_AT = "modified_at";
	private static final String RESPONSE = "response";
	private static final String STATUS = "status";

	private static final String FIELDS[] = new String[] { CREATED_AT, MODIFIED_AT, RESPONSE, STATUS };

	@Override
	public void saveRequest(DlmsReqRespMsg request) {
		Key key = makeKey(request);
		Bin bin1 = new Bin(CORRELID, getCorrelId(request));
		Bin bin2 = new Bin(CREATED_AT, now());
		Bin bin3 = new Bin(MODIFIED_AT, "");
		Bin bin4 = new Bin(RESPONSE, "");
		Bin bin5 = new Bin(STATUS, "");

		WritePolicy wPolicy = new WritePolicy();
		wPolicy.recordExistsAction = RecordExistsAction.UPDATE;
		client().put(wPolicy, key, bin1, bin2, bin3, bin4, bin5);
	}

	private static int count = 0;
	
	@Override
	public void updateWithResponse(final String correlId, final String responseMsg, final String statusMsg) {
		Key key = makeKey(correlId);
		Record record = client().get(null, key);
		if (record != null) {
			Bin bin3 = new Bin(MODIFIED_AT, now());
			Bin bin4 = new Bin(RESPONSE, responseMsg);
			Bin bin5 = new Bin(STATUS, statusMsg);
			client().put(null, key, bin3, bin4, bin5);
			
			showProgress();
		} else {
			logger.log(Level.WARNING, "key not found");
		}
	}

	private void showProgress() {
		count++;
		if (count % 500 == 0) {
			System.err.println("update with response " + count);
		} 
	}

	@Override
	public String getResponse(final DlmsRespCorrelIdMsg responseCorrelIdMsg) {
		Key key = makeKey(responseCorrelIdMsg.getCorrelid());
		Record record = client().get(null, key);
		if (record != null) {
			StringBuffer sb = new StringBuffer();
			for (String fld : FIELDS) {
				sb.append(record.getValue(fld).toString() + ";");
			}
			return sb.toString();
		} else {
			return "Record not available";
		}
	}

	private Key makeKey(String correlid) {
		return new Key(NAMESPACE, TABLE_REQRESP_MSG, correlid);
	}

	private Key makeKey(DlmsReqRespMsg request) {
		return new Key(NAMESPACE, TABLE_REQRESP_MSG, getCorrelId(request));
	}


	private String getCorrelId(DlmsReqRespMsg request) {
		return request.getCommon().getCorrelId();
	}


	private long now() {
		return new Date().getTime();
	}


	private AerospikeClient client() {
		return SmIntAerospikeServer.getInstance().client();
	}

}
