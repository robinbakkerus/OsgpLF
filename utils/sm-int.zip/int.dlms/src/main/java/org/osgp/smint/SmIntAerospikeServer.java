package org.osgp.smint;

import java.util.logging.Logger;

import com.aerospike.client.AerospikeClient;
import com.aerospike.client.policy.ClientPolicy;

public class SmIntAerospikeServer  {

	private static final Logger logger = Logger.getLogger(SmIntAerospikeServer.class.getName());

	private static SmIntAerospikeServer sInstance = null;
	
	private ClientPolicy cPolicy = new ClientPolicy();
	private AerospikeClient client;

	private SmIntAerospikeServer(final String host, final int port) {
		cPolicy.timeout = 500;
		client = new AerospikeClient(cPolicy, host, port);
	}
	
	public static SmIntAerospikeServer initialize(final String host, final int port) {
		if (sInstance == null) {
			sInstance = new SmIntAerospikeServer(host, port);
		}
		return sInstance;
	}

	public static SmIntAerospikeServer getInstance() {
		if (sInstance != null) {
			return sInstance;
		} else {
			throw new RuntimeException("Aerospike has not been setup yet");
		}
	}
	
	public AerospikeClient client()  {
		if (client != null) {
			return client;
		} else {
			logger.severe("Aerospike has not been setup yet");
			throw new RuntimeException("Aerospike has not been setup yet");
		}
	}
	
	public void cleanup()  {
		if (this.client != null) {
			this.client.close();
		}
	}
}
