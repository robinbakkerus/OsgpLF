package org.osgp.smint.dbs;

import com.alliander.osgp.dlms.DlmsReqRespMsg;
import com.alliander.osgp.dlms.DlmsRespCorrelIdMsg;

public interface RequestResponseDao {

	void saveRequest(final DlmsReqRespMsg request);
	
	void updateWithResponse(final String correlId, final String responseMsg, final String statusMsg);
	
	String getResponse(final DlmsRespCorrelIdMsg responseCorrelIdMsg);
}
